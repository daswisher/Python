import pygame

import state
import title
import game

pygame.init()
#Sets the dimensions of the game window
display = pygame.display.set_mode((1000,600))
#Changes the title bar on the program window
pygame.display.set_caption("Coldwake Orange {Alpha}")

class coldwake():
	#Initializes the game state
    def __init__(self):
        self.sm = state.StateMachine(self, title.Title())

    def start(self):
        while True:
            self.sm.update()

if __name__ == "__main__":
    game = coldwake()
    game.start()
